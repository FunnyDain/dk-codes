package springjpa.exam.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WeatherDTO {
	String time;
	String img;
}
